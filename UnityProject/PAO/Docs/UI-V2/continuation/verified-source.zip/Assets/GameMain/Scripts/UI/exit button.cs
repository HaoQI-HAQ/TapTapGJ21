using UnityEngine;

public class QuitGameBtn : MonoBehaviour
{
    public AudioClip clickSound;
    private AudioSource audioSource;

    void Awake()
    {
        audioSource = GetComponent<AudioSource>();
        if (audioSource == null)
        {
            audioSource = gameObject.AddComponent<AudioSource>();
        }
    }

    public void QuitGame()
    {
        if (clickSound != null)
        {
            audioSource.PlayOneShot(clickSound);
        }

#if UNITY_EDITOR
        Debug.Log("�༭��ģʽ���˳���Ϸ���������Ч");
#else
        Application.Quit();
#endif
    }
}
