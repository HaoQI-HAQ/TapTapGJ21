using System;
using UnityEngine;

namespace PAO.UI.V2
{
    public static class UIInput
    {
        private static readonly KeyCode[] DefaultBindings = UISettingsData.DefaultKeys();
        public const int Interact = 3, Journal = 4, Help = 5, Forward = 6, Backward = 7,
            Left = 8, Right = 9, Jump = 10, Sprint = 11, Ride = 12, Charge = 13, Detonate = 14;
        public static bool UsesV2 { get { return UIRuntime.Instance != null && UIRuntime.Instance.IsGameplay; } }
        public static bool Blocked { get { return UIRuntime.Instance != null && UIRuntime.Instance.BlocksInputThisFrame; } }
        public static bool IsBindable(KeyCode key)
        {
            return Enum.IsDefined(typeof(KeyCode), key) && key > KeyCode.None && key <= KeyCode.Mouse6 &&
                key != KeyCode.Escape && key != KeyCode.Return && key != KeyCode.KeypadEnter && key != KeyCode.Tab &&
                key != KeyCode.UpArrow && key != KeyCode.DownArrow && key != KeyCode.LeftArrow && key != KeyCode.RightArrow;
        }
        public static KeyCode Binding(int action)
        {
            if (action < 0 || action >= DefaultBindings.Length) return KeyCode.None;
            return UISettings.Current != null && UISettings.Current.keys != null && action < UISettings.Current.keys.Length ?
                UISettings.Current.keys[action] : DefaultBindings[action];
        }
        public static bool Down(int action, KeyCode controller = KeyCode.None)
        { return !Blocked && (Input.GetKeyDown(Binding(action)) || (controller != KeyCode.None && Input.GetKeyDown(controller))); }
        public static bool Held(int action, KeyCode controller = KeyCode.None)
        { return !Blocked && (Input.GetKey(Binding(action)) || (controller != KeyCode.None && Input.GetKey(controller))); }
        public static Vector2 Move()
        {
            float horizontal = (Held(Right) ? 1 : 0) - (Held(Left) ? 1 : 0);
            float vertical = (Held(Forward) ? 1 : 0) - (Held(Backward) ? 1 : 0);
            Vector2 stick = new Vector2(Input.GetAxisRaw("PAOMoveX"), Input.GetAxisRaw("PAOMoveY"));
            return Vector2.ClampMagnitude(new Vector2(horizontal, vertical) + stick, 1);
        }
        public static string KeyName(int action)
        {
            return KeyName(Binding(action));
        }
        public static string KeyName(KeyCode key)
        {
            switch (key)
            {
                case KeyCode.Mouse0: return UISettings.Text("鼠标左键", "Left mouse");
                case KeyCode.Mouse1: return UISettings.Text("鼠标右键", "Right mouse");
                case KeyCode.Mouse2: return UISettings.Text("鼠标中键", "Middle mouse");
                case KeyCode.Space: return UISettings.Text("空格", "Space");
                case KeyCode.LeftShift: return "Shift";
            }
            if (key >= KeyCode.Alpha0 && key <= KeyCode.Alpha9) return ((int)key - (int)KeyCode.Alpha0).ToString();
            return key.ToString();
        }
        public static string MovementHint()
        { return KeyName(Forward) + "/" + KeyName(Left) + "/" + KeyName(Backward) + "/" + KeyName(Right); }
    }
}
